package com.jokerpay.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.NumberFormat
import java.util.Locale

private val Navy = Color(0xFF0B1220)
private val Panel = Color(0xFF142235)
private val Teal = Color(0xFF2DD4BF)
private val Muted = Color(0xFF9CB3C7)
private val White = Color(0xFFF7FAFC)
private val Green = Color(0xFF34D399)
private val Red = Color(0xFFF87171)

private fun money(value: Long): String =
    NumberFormat.getCurrencyInstance(Locale("en", "IN")).format(value)

private data class Tx(val title: String, val amount: Long, val isCredit: Boolean)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { JokerPayApp() }
    }
}

@Composable
private fun JokerPayApp() {
    var selected by remember { mutableStateOf("Home") }
    var balance by remember { mutableLongStateOf(25000L) }
    var amountInput by remember { mutableStateOf("500") }
    var message by remember { mutableStateOf("Welcome to Joker Pay demo") }
    var txs by remember { mutableStateOf(listOf(Tx("Starter demo balance", 25000, true))) }
    var savings by remember { mutableFloatStateOf(0.60f) }
    var portfolio by remember { mutableLongStateOf(10000L) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Teal, onPrimary = Navy, background = Navy, surface = Panel,
            onSurface = White, onBackground = White, secondary = Muted
        )
    ) {
        Scaffold(
            containerColor = Navy,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF101C2B), contentColor = White) {
                    listOf(
                        Triple("Home", Icons.Default.Home, "Home"),
                        Triple("Wallet", Icons.Default.AccountBalanceWallet, "Wallet"),
                        Triple("Stocks", Icons.Default.ShowChart, "Stocks"),
                        Triple("Savings", Icons.Default.Savings, "Savings"),
                        Triple("History", Icons.Default.History, "History")
                    ).forEach { (label, icon, screen) ->
                        NavigationBarItem(
                            selected = selected == screen,
                            onClick = { selected = screen },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Teal, selectedTextColor = Teal,
                                indicatorColor = Color(0xFF164E4A),
                                unselectedIconColor = Muted, unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(18.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier.size(48.dp).background(Teal, RoundedCornerShape(15.dp)),
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.Default.AccountBalanceWallet, null, tint = Navy, modifier = Modifier.size(28.dp)) }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Joker Pay", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = White)
                            Text("PAY  •  SAVE  •  INVEST", fontSize = 11.sp, color = Muted, letterSpacing = 1.sp)
                        }
                        Surface(color = Color(0xFF263B35), shape = CircleShape) {
                            Text("DEMO", color = Teal, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp))
                        }
                    }
                }
                item {
                    when (selected) {
                        "Home" -> {
                            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                                BalanceCard(balance)
                                Text("Quick actions", fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    QuickAction("Add money", Icons.Default.Add, Modifier.weight(1f)) { selected = "Wallet" }
                                    QuickAction("Withdraw", Icons.Default.ArrowUpward, Modifier.weight(1f)) { selected = "Wallet" }
                                    QuickAction("History", Icons.Default.History, Modifier.weight(1f)) { selected = "History" }
                                }
                                Text("Explore", fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
                                FeatureCard("Stock trading", "Practice buying and selling with virtual money", Icons.Default.ShowChart) { selected = "Stocks" }
                                FeatureCard("Savings goal", "Build a habit and track your progress", Icons.Default.Savings) { selected = "Savings" }
                                DemoNotice()
                            }
                        }
                        "Wallet" -> {
                            Text("Digital wallet", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                            BalanceCard(balance)
                            Text("Amount (₹)", color = Muted)
                            OutlinedTextField(
                                value = amountInput, onValueChange = { amountInput = it.filter(Char::isDigit).take(9) },
                                modifier = Modifier.fillMaxWidth(), singleLine = true,
                                placeholder = { Text("Enter amount") },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = Teal, unfocusedBorderColor = Muted,
                                    focusedTextColor = White, unfocusedTextColor = White
                                )
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Button(
                                    onClick = {
                                        val amount = amountInput.toLongOrNull()
                                        if (amount != null && amount > 0) {
                                            balance += amount
                                            txs = listOf(Tx("Demo money added", amount, true)) + txs
                                            message = "${money(amount)} added in simulation"
                                        } else message = "Enter a valid amount"
                                    }, modifier = Modifier.weight(1f)
                                ) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Add demo") }
                                OutlinedButton(
                                    onClick = {
                                        val amount = amountInput.toLongOrNull()
                                        if (amount != null && amount > 0 && amount <= balance) {
                                            balance -= amount
                                            txs = listOf(Tx("Demo withdrawal", amount, false)) + txs
                                            message = "${money(amount)} withdrawn in simulation"
                                        } else message = "Invalid amount or insufficient demo balance"
                                    }, modifier = Modifier.weight(1f)
                                ) { Icon(Icons.Default.ArrowUpward, null); Spacer(Modifier.width(6.dp)); Text("Withdraw") }
                            }
                            InfoBanner(message)
                            DemoNotice()
                        }
                        "Stocks" -> {
                            Text("Stock market", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                            Text("Practice mode • Prices below are illustrative, not live", color = Muted, fontSize = 12.sp)
                            BalanceCard(portfolio, "Virtual portfolio")
                            MiniChart()
                            listOf(
                                Triple("NIFTY 50", "Index example", 24500L),
                                Triple("Reliance", "Stock example", 1250L),
                                Triple("Tata Motors", "Stock example", 780L)
                            ).forEach { (name, kind, price) ->
                                Surface(color = Panel, shape = RoundedCornerShape(16.dp)) {
                                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f)) {
                                            Text(name, fontWeight = FontWeight.SemiBold)
                                            Text(kind, color = Muted, fontSize = 12.sp)
                                            Text(money(price), color = White, fontWeight = FontWeight.Medium)
                                        }
                                        Button(onClick = {
                                            if (portfolio >= price) {
                                                portfolio -= price
                                                message = "Simulated buy: $name at ${money(price)}. No real order placed."
                                            } else message = "Not enough virtual portfolio funds"
                                        }) { Text("Buy demo") }
                                    }
                                }
                            }
                            InfoBanner(message)
                            DemoNotice()
                        }
                        "Savings" -> {
                            Text("Savings goals", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                            Surface(color = Panel, shape = RoundedCornerShape(20.dp)) {
                                Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Icon(Icons.Default.Savings, null, tint = Teal, modifier = Modifier.size(36.dp))
                                    Text("Emergency fund", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                    Text("${(savings * 100).toInt()}% of ₹10,000 goal", color = Muted)
                                    LinearProgressIndicator(progress = { savings }, modifier = Modifier.fillMaxWidth(), color = Teal, trackColor = Color(0xFF34465A))
                                    Text("Saved: ${money((savings * 10000).toLong())}", color = White)
                                    Button(onClick = { savings = (savings + 0.05f).coerceAtMost(1f); message = "Savings progress updated (demo)" }) {
                                        Text("Add 5% progress")
                                    }
                                }
                            }
                            InfoBanner(message)
                            DemoNotice()
                        }
                        else -> {
                            Text("Transaction history", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                            txs.forEach { tx ->
                                Surface(color = Panel, shape = RoundedCornerShape(14.dp)) {
                                    Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Icon(if (tx.isCredit) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward, null, tint = if (tx.isCredit) Green else Red)
                                        Spacer(Modifier.width(12.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(tx.title, fontWeight = FontWeight.Medium)
                                            Text("Simulation only", color = Muted, fontSize = 11.sp)
                                        }
                                        Text((if (tx.isCredit) "+" else "−") + money(tx.amount), color = if (tx.isCredit) Green else Red, fontWeight = FontWeight.SemiBold)
                                    }
                                }
                            }
                            DemoNotice()
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BalanceCard(balance: Long, label: String = "Demo wallet balance") {
    Surface(
        color = Color(0xFF142C3B), shape = RoundedCornerShape(24.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF245267))
    ) {
        Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(label, color = Color(0xFFA9C5D3), fontSize = 13.sp)
            Text(money(balance), color = White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
            Surface(color = Color(0xFF214C45), shape = CircleShape) {
                Text("VIRTUAL FUNDS ONLY", color = Teal, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
            }
        }
    }
}

@Composable
private fun QuickAction(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Surface(modifier = modifier.clickable(onClick = onClick), color = Panel, shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(vertical = 16.dp, horizontal = 6.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(icon, null, tint = Teal)
            Text(label, fontSize = 11.sp, color = White)
        }
    }
}

@Composable
private fun FeatureCard(title: String, description: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Surface(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick), color = Panel, shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Teal, modifier = Modifier.size(30.dp))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(description, color = Muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun InfoBanner(message: String) {
    Surface(color = Color(0xFF173A38), shape = RoundedCornerShape(12.dp)) {
        Text(message, color = Teal, fontSize = 12.sp, modifier = Modifier.fillMaxWidth().padding(12.dp))
    }
}

@Composable
private fun DemoNotice() {
    Surface(color = Color(0xFF30291B), shape = RoundedCornerShape(12.dp)) {
        Text(
            "Demo only: no real money, bank connection, live market data, or real orders.",
            color = Color(0xFFFDE68A), fontSize = 11.sp, modifier = Modifier.padding(12.dp)
        )
    }
}

@Composable
private fun MiniChart() {
    Surface(color = Panel, shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Text("Illustrative market trend", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            Canvas(Modifier.fillMaxWidth().height(120.dp)) {
                val values = listOf(.72f, .62f, .67f, .43f, .50f, .31f, .40f, .22f, .34f, .17f, .24f)
                val path = Path()
                values.forEachIndexed { i, v ->
                    val x = size.width * i / (values.size - 1)
                    val y = size.height * v
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                drawPath(path, Teal, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 4f))
                for (i in 1..3) {
                    val y = size.height * i / 4
                    drawLine(Color(0xFF34465A), Offset(0f, y), Offset(size.width, y), strokeWidth = 1f)
                }
            }
        }
    }
}
